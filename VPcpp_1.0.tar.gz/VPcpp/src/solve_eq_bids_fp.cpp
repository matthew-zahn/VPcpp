#include <RcppArmadillo.h>

// [[Rcpp::depends(RcppArmadillo)]]


// Enable C++11 via this plugin (Rcpp 0.10.3 or later)
// [[Rcpp::plugins(cpp11)]]
//using namespace Rcpp;
//using namespace arma;

// [[Rcpp::export]]
arma::vec solve_eq_bids_fp_cpp(arma::mat bidold, const arma::mat OwnerMat, const arma::mat SAManCompDF, const arma::mat SAcov, 
                            const arma::mat SAindex, const arma::vec SAdshocks, const arma::vec SAmcshocks, const arma::vec SAeffshocks, 
                            const arma::mat M, arma::vec alpha1, arma::vec alpha2, arma::vec sigma, const double tol, const int maxit){

	// Define objects that are fixed across iterations
	arma::vec bids = bidold.col(3) ;
	arma::vec benchmarks = SAManCompDF.col(3);
	arma::vec rebate_rate = SAManCompDF.col(4);
	arma::vec cov = SAcov.col(3);
	arma::vec flag_exog = bidold.col(2);
	arma::uvec end_prods = find(flag_exog == 0);
	arma::uvec exo_prods = find(flag_exog == 1);
	int j = cov.n_elem;
	
  // Set up MSFP
  double norm = 1 ;
  int it = 0 ;
  while (norm > tol && it < maxit){
    
    // Given bids, calculate rebates and premiums
    int size = rebate_rate.n_elem;
    arma::vec rebate = arma::zeros<arma::vec>(size);
    arma::vec bid_prem = arma::zeros<arma::vec>(size);
    arma::vec supp_premium = arma::zeros<arma::vec>(size);
    arma::vec adj = arma::ones<arma::vec>(size);
    arma::vec PARAM = arma::zeros<arma::vec>(size);
    for (int index = 0; index < size; index++){
      if (bids[index] < benchmarks[index]){
        rebate[index] = rebate_rate[index] * (benchmarks[index] - bids[index]);
        bid_prem[index] = 0;
        adj[index] = adj[index] + rebate_rate[index];
        PARAM[index] = alpha2[0] * rebate_rate[index];
      }
      else{
        rebate[index] = 0;
        bid_prem[index] = bids[index] - benchmarks[index];
        PARAM[index] = alpha2[0];
      }
      arma::vec temp = {0, cov[index] - rebate[index] + SAeffshocks[index]};
      supp_premium[index] = max(temp) ;
    }
    
    // Given extra coverage, rebates, and bid premiums calculate prices
    arma::vec price = supp_premium + bid_prem;
    
    // Create matrices at the market level with the firm characteristics
    arma::vec plans = unique(SAindex.col(1));
    arma::mat covplans = SAcov.col(0);
    arma::mat market_plans = SAindex.col(1);
    arma::mat covmat = arma::zeros<arma::mat>(market_plans.n_rows,1);
    arma::mat pmat = arma::zeros<arma::mat>(market_plans.n_rows,1);
    int nrows = market_plans.n_rows;
    int p_size = plans.n_elem;
    for (int index = 0; index < p_size; index++){
      arma::vec flag_plan = arma::zeros<arma::vec>(nrows);
      for (int jndex = 0; jndex < nrows; jndex++){
        if (market_plans[jndex] == plans[index]){
          flag_plan[jndex] = 1;
        }
        else{
          flag_plan[jndex] = 0;
        }
      }
      
      arma::uvec index2 = find(covplans == plans[index]);
      arma::mat flag_plan_cov = flag_plan * cov(index2);
      arma::mat flag_plan_p = flag_plan * price(index2);
      covmat = covmat + flag_plan_cov;
      pmat = pmat + flag_plan_p;
    }
    
    // Given prices and coverage, calculate shares in each market in service area
    arma::mat delta = SAdshocks + alpha1[0] * covmat + alpha2[0] * pmat ; 
    
    arma::vec markets = unique(SAindex.col(0));
    arma::mat market_plans2 = SAindex.col(0);
    arma::mat shares = arma::zeros<arma::mat>(market_plans2.n_rows,1);
    int m_size = markets.n_elem;
    for (int index = 0; index < m_size; index++){
      arma::mat delta2 = delta.elem(find(market_plans2 == markets[index]));
      int obs = delta2.n_rows;
      arma::vec den = arma::ones<arma::vec>(obs) * (1 - sigma); 
      arma::mat dexp = exp( delta2 / den);
      
      // Calculate the denominator of the within nest share expression
      arma::mat denom = repmat(sum(dexp),obs,1);
      
      // WITHIN NEST SHARES
      arma::mat sbar_jm = dexp / denom;
      
      // GROUP SHARES
      arma::mat s_gm = pow(denom,(1-sigma[0])) / (1 + pow(denom,(1-sigma[0])));
      
      // MARKET SHARES
      arma::mat s_jm = sbar_jm % s_gm;
      
      shares.elem(find(market_plans2 == markets[index])) = s_jm;
    }
    // Rcout << "----Market shares" << endl;
    //Rcout << shares << endl;
    
    // Given shares, calculate service area enrollment shares
    arma::mat enrollment = shares % M.col(7);
    arma::mat market_plans3 = SAindex.col(1);
    arma::mat sa_enrollment = arma::zeros<arma::mat>(plans.n_elem,1); 
    int rows = market_plans3.n_rows ; 
    for (int index = 0; index < p_size; index++){
      arma::vec flag_plan = arma::zeros<arma::vec>(rows);
      for (int jndex = 0; jndex < rows; jndex++){
        if (market_plans3[jndex] == plans[index]){
          flag_plan[jndex] = 1;
        }
        else{
          flag_plan[jndex] = 0;
        }
      }
      
      arma::uvec index2 = find(covplans == plans[index]);
      arma::mat flag_plan_enroll = enrollment % flag_plan;
      sa_enrollment.elem(index2) = sum(flag_plan_enroll);
    }
    
    // vec tot_sa_enrollment = ones<vec>(j) * sum(sa_enrollment);
    // mat s_j = sa_enrollment / tot_sa_enrollment;
    arma::vec market_size = M.col(7);
    arma::mat t_mark_size = arma::zeros<arma::vec>(m_size);
    for (int index = 0; index < m_size; index++){
      arma::uvec mrows = find(M.col(0) == markets[index]);
      int mlook = mrows[0];
      t_mark_size[index] = market_size[mlook];
    }
    arma::vec tot_market_size = arma::ones<arma::vec>(j) * sum(t_mark_size);
    arma::mat s_j = sa_enrollment / tot_market_size;
    arma::vec sum_s_j = sum(s_j);
    arma::mat s_g = arma::ones<arma::mat>(j,1) * sum_s_j;
    arma::mat sbar_j = s_j % (1/s_g);
    
    // Calculate derivative matrix
    arma::mat derivMat = arma::zeros<arma::mat>(j,j);
    double ds_dd = 0;
    for (int col = 0; col < j; col++){
      for (int row = 0; row < j; row++){
        if (col == row){
          ds_dd = (1 / (1 - sigma[0])) * s_j[row] * (1 - sigma[0]*sbar_j[row] - (1 - sigma[0])*s_j[row]);
        }
        else{
          ds_dd = -1 * s_j[col] * s_j[row] * (1 + sigma[0]/(1 - sigma[0]) * 1/s_g[row]);
        }
        derivMat(row,col) = ds_dd ; 
      }
    }
    for (int col = 0; col < j; col++){
      derivMat.col(col) = PARAM % derivMat.col(col);  
    }
    // Rcout << "derivMat:" << endl;
    // Rcout << derivMat << endl;
    
    // Factor derivMat into components
    arma::vec lambda = (alpha2[0] / (1 - sigma[0])) * s_j; 
    arma::mat Lambda = diagmat(lambda);
    arma::mat Gamma = -1*(derivMat - Lambda); 
    
    // Calculate zeta
    arma::mat invLambda = inv(Lambda);
    arma::vec zeta = invLambda * (OwnerMat % Gamma) * (bids - SAmcshocks) - invLambda * (adj % s_j);
    
    // Calculate FOC
    arma::vec obj = Lambda * (bids - SAmcshocks - zeta);
    
    // Loop to replace obj = 0 for exog prods
    int n_exo_prods = exo_prods.n_elem;
    for (int index = 0; index < n_exo_prods; index++){
      int exoindex = exo_prods[index];
      obj[exoindex] = 0;
    }
    
    // Update bids for the endogenous products
    int n_end_prods = end_prods.n_elem;
    arma::vec new_bids = SAmcshocks + zeta;
    for (int index = 0; index < n_end_prods; index++){
      int endindex = end_prods[index];
      bids[endindex] = new_bids[endindex];
    }
    
    // Compute norm off of FOCs
    norm = max(abs(obj));
    // Rcout << "iter: " << it << " nrm: " << norm << endl;
    it++;
    
    // Rcout << "----Completed iteration" << endl;
    
  } 
	
	return bids ;
  
}

