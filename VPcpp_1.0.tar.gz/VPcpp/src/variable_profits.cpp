#include <RcppArmadillo.h>

// [[Rcpp::depends(RcppArmadillo)]]


// Enable C++11 via this plugin (Rcpp 0.10.3 or later)
// [[Rcpp::plugins(cpp11)]]
//using namespace Rcpp;
//using namespace arma;

// [[Rcpp::export]]
double variable_profits_cpp(arma::vec bid_firm, const arma::mat bidold, const int firm, const arma::vec brows, const arma::mat SAManCompDF, const arma::mat SAcov, 
                            const arma::mat SAindex, const arma::vec SAdshocks, const arma::vec SAmcshocks, const arma::vec SAeffshocks, 
                            const arma::mat M, const arma::vec SAlogeccshocks, arma::vec alpha1, arma::vec alpha2, arma::vec sigma, arma::vec ecc_extra_cov, const int outopt){

	// Declare objects to be created
	arma::vec bids;
	arma::vec rebate;
	arma::vec bid_prem;
	arma::vec supp_premium;
	arma::vec price;
	
	// Fill in bids 
	bids = bidold.col(3) ;
	int b_size = brows.n_elem;
	for (int index = 0; index < b_size ; index++){
	  int bindex = brows[index] - 1;
	  bids[bindex] = bid_firm[index];
	}
	arma::vec benchmarks = SAManCompDF.col(3);
	arma::vec rebate_rate = SAManCompDF.col(4);
	arma::vec cov = SAcov.col(3);
	int size = rebate_rate.n_elem;
	rebate = arma::zeros<arma::vec>(size);
	bid_prem = arma::zeros<arma::vec>(size);
	supp_premium = arma::zeros<arma::vec>(size);
	for (int index = 0; index < size; index++){
	  if (bids[index] < benchmarks[index]){
	    rebate[index] = rebate_rate[index] * (benchmarks[index] - bids[index]);
	    bid_prem[index] = 0;
	  }
	  else{
	    rebate[index] = 0;
	    bid_prem[index] = bids[index] - benchmarks[index];
	  }
	  arma::vec temp = {0, cov[index] - rebate[index] + SAeffshocks[index]};
	  supp_premium[index] = max(temp) ;
	}

	// Given extra coverage, rebates, and bid premiums calculate prices
	price = supp_premium + bid_prem; 

	// Create matrices at the market level with the firm characteristics
	arma::vec plans = unique(SAindex.col(1));
	arma::mat covplans = SAcov.col(0);
	arma::mat market_plans = SAindex.col(1);
	arma::mat covmat = arma::zeros<arma::mat>(market_plans.n_rows,1);
	arma::mat pmat = arma::zeros<arma::mat>(market_plans.n_rows,1);
	int nrows = market_plans.n_rows;
	int p_size = plans.n_elem;
  for (int index = 0; index < p_size; index++){
    arma::vec flag_plan = arma::zeros<arma::vec>(nrows);
    for (int jndex = 0; jndex < nrows; jndex++){
      if (market_plans[jndex] == plans[index]){
        flag_plan[jndex] = 1;
      }
      else{
        flag_plan[jndex] = 0;
      }
    }
    
    arma::uvec index2 = find(covplans == plans[index]);
    arma::mat flag_plan_cov = flag_plan * cov(index2);
    arma::mat flag_plan_p = flag_plan * price(index2);
    covmat = covmat + flag_plan_cov;
    pmat = pmat + flag_plan_p;
  }

  // Given prices and coverage, calculate shares in each market in service area
  arma::mat delta = SAdshocks + alpha1[0] * covmat + alpha2[0] * pmat ; 
  
  arma::vec markets = unique(SAindex.col(0));
  arma::mat market_plans2 = SAindex.col(0);
  arma:: mat shares = arma::zeros<arma::mat>(market_plans2.n_rows,1);
  int m_size = markets.n_elem;
  for (int index = 0; index < m_size; index++){
    arma::mat delta2 = delta.elem(find(market_plans2 == markets[index]));
    int obs = delta2.n_rows;
    arma::vec den = arma::ones<arma::vec>(obs) * (1 - sigma); 
    arma::mat dexp = exp( delta2 / den);
    
    // Calculate the denominator of the within nest share expression
    arma::mat denom = repmat(sum(dexp),obs,1);

    // WITHIN NEST SHARES
    arma::mat sbar_jm = dexp / denom;
      
    // GROUP SHARES
    arma::mat s_gm = pow(denom,(1-sigma[0])) / (1 + pow(denom,(1-sigma[0])));
        
    // MARKET SHARES
    arma::mat s_jm = sbar_jm % s_gm;
    
    shares.elem(find(market_plans2 == markets[index])) = s_jm;
  }
  // Rcout << "----Shares" << endl;
  // Rcout << shares << endl;
	
  // Given shares, calculate market and service area enrollment
  arma::mat enrollment = shares % M.col(7);
  arma::mat market_plans3 = SAindex.col(1);
  arma::mat sa_enrollment = arma::zeros<arma::mat>(plans.n_elem,1); 
  int rows = market_plans3.n_rows ; 
  for (int index = 0; index < p_size; index++){
    arma::vec flag_plan = arma::zeros<arma::vec>(rows);
    for (int jndex = 0; jndex < rows; jndex++){
      if (market_plans3[jndex] == plans[index]){
        flag_plan[jndex] = 1;
      }
      else{
        flag_plan[jndex] = 0;
      }
    }
    
    arma::uvec index2 = find(covplans == plans[index]);
    arma::mat flag_plan_enroll = enrollment % flag_plan;
    sa_enrollment.elem(index2) = sum(flag_plan_enroll);
  }
  
  // Given service area enrollment, calculate profits, Endogenous plans only. 
  arma::vec covfirms = SAcov.col(1);
  arma::mat pi1 = (bids - SAmcshocks) % sa_enrollment ;
  arma::vec flag_end = arma::ones<arma::vec>(SAManCompDF.n_rows) - SAManCompDF.col(2);
  int firm_profit;
  if (outopt == 1){
    pi1 = pi1 % flag_end;
    firm_profit = sum(pi1(find(covfirms == firm)));
  }
  else{
    arma::vec extra_cov_cost = exp(SAlogeccshocks + (ecc_extra_cov[0] * cov));
    arma::mat pi2 = pi1 + (supp_premium % sa_enrollment) - (extra_cov_cost % sa_enrollment);
    pi2 = pi2 % flag_end;
    firm_profit = sum(pi2(find(covfirms == firm))); 
  }
  int func_out ; 
  func_out = -1 * firm_profit;

	return func_out ;

}

